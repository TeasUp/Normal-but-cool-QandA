function AddnewQA(param){
   $("#" + param).removeClass("d-none")
}

function deltopic(delparam){
   $("#" + delparam).addClass("d-none")
}